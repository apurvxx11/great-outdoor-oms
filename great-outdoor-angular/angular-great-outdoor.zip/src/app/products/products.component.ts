import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductServeService } from '../product-serve.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {


  produc: Product[];
  constructor(private product_obj: ProductServeService) { }

  ngOnInit(): void {
    this.product_obj.getProducts().subscribe((data)=>{
      this.produc = data;},
      error=>
      {
        console.log("error occured",error);
      }
      
    );
  }

}
