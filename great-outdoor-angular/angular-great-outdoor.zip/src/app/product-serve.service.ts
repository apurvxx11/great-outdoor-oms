import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductServeService {

  constructor(private http: HttpClient) { }

  getProducts(): Observable<any>{
    let url = "http://localhost:1187/products";
    return this.http.get(url);

  }
}
