
export class Product {

    id: number;
    name: String;
    quantity: number;
    mrp: number;
    manufacturer: String;
    product_size: number;

}
