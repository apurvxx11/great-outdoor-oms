import { TestBed } from '@angular/core/testing';

import { ProductServeService } from './product-serve.service';

describe('ProductServeService', () => {
  let service: ProductServeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProductServeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
